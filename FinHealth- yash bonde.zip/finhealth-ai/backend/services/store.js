/**
 * FinHealth AI - In-memory and resilient data store
 * Mirrored directly to the Supabase PostgreSQL schema.
 * Pre-seeded with Demo User "Rahul Sharma" for zero-friction evaluation.
 */

// Helper to calculate CIBIL / Indian credit score category
export function getCreditScoreCategory(score) {
  if (score >= 800) return { category: 'Excellent', color: 'emerald', min: 800, max: 900 };
  if (score >= 740) return { category: 'Very Good', color: 'teal', min: 740, max: 799 };
  if (score >= 670) return { category: 'Good', color: 'blue', min: 670, max: 739 };
  if (score >= 580) return { category: 'Fair', color: 'amber', min: 580, max: 669 };
  return { category: 'Poor', color: 'rose', min: 300, max: 579 };
}

// Helper to calculate DTI category
export function getDtiCategory(dti) {
  if (dti <= 20) return { category: 'Excellent', status: 'Healthy', color: 'emerald' };
  if (dti <= 35) return { category: 'Good', status: 'Manageable', color: 'blue' };
  if (dti <= 49) return { category: 'Moderate', status: 'Caution Needed', color: 'amber' };
  return { category: 'High Risk', status: 'Critical Debt Burden', color: 'rose' };
}

export function calculateFinancialMetrics(data) {
  const monthlyIncome = Math.max(0, Number(data.monthlyIncome || data.monthly_income || 0));
  const monthlyExpenses = Math.max(0, Number(data.monthlyExpenses || data.monthly_expenses || 0));
  const totalDebt = Math.max(0, Number(data.totalDebt || data.total_debt || 0));
  const monthlyEmi = Math.max(0, Number(data.monthlyEmi || data.monthly_emi || 0));
  const creditLimit = Math.max(0, Number(data.creditLimit || data.credit_limit || 0));
  const creditCardOutstanding = Math.max(0, Number(data.creditCardOutstanding || data.credit_card_outstanding || 0));
  const creditScore = Math.min(900, Math.max(300, Number(data.creditScore || data.credit_score || 650)));
  const activeLoans = Math.max(0, Number(data.activeLoansCount || data.active_loans_count || 1));

  // DTI = (Total Monthly Debt Payments / Gross Monthly Income) * 100
  const dtiRatio = monthlyIncome > 0 ? Number(((monthlyEmi / monthlyIncome) * 100).toFixed(2)) : 0;

  // Credit Utilization = (Credit Card Outstanding / Total Credit Limit) * 100
  const creditUtilization = creditLimit > 0 ? Number(((creditCardOutstanding / creditLimit) * 100).toFixed(2)) : 0;

  // Available Credit
  const availableCredit = Math.max(0, creditLimit - creditCardOutstanding);

  // Net Savings Potential
  const netSavings = Math.max(0, monthlyIncome - (monthlyExpenses + monthlyEmi));

  const scoreCat = getCreditScoreCategory(creditScore);
  const dtiCat = getDtiCategory(dtiRatio);

  return {
    creditScore,
    scoreCategory: scoreCat.category,
    monthlyIncome,
    monthlyExpenses,
    totalDebt,
    monthlyEmi,
    creditLimit,
    creditCardOutstanding,
    activeLoansCount: activeLoans,
    dtiRatio,
    dtiCategory: dtiCat.category,
    dtiStatus: dtiCat.status,
    creditUtilization,
    availableCredit,
    netSavings
  };
}

// Initial demo seed data
const DEMO_USER_ID = 'demo-rahul-sharma-id';

function createFreshSeed() {
  const users = [
    {
      id: DEMO_USER_ID,
      name: 'Rahul Sharma',
      email: 'rahul.sharma@example.com',
      passwordHash: 'demo_password_hash',
      createdAt: '2025-01-01T10:00:00.000Z'
    }
  ];

  const financialProfiles = {
    [DEMO_USER_ID]: {
      id: 'profile-rahul-01',
      userId: DEMO_USER_ID,
      creditScore: 650,
      monthlyIncome: 60000,
      monthlyExpenses: 35000,
      totalDebt: 250000,
      monthlyEmi: 12000,
      creditLimit: 100000,
      creditCardOutstanding: 35000,
      activeLoansCount: 2,
      creditUtilization: 35.0,
      dtiRatio: 20.0,
      createdAt: '2025-01-01T10:00:00.000Z',
      updatedAt: '2025-06-15T12:00:00.000Z'
    }
  };

  const creditHistory = {
    [DEMO_USER_ID]: [
      { id: 'ch-1', userId: DEMO_USER_ID, creditScore: 620, recordedAt: '2025-01-15T09:00:00.000Z', month: 'Jan', remarks: 'Baseline assessment' },
      { id: 'ch-2', userId: DEMO_USER_ID, creditScore: 635, recordedAt: '2025-02-15T09:00:00.000Z', month: 'Feb', remarks: 'Timely EMI payment' },
      { id: 'ch-3', userId: DEMO_USER_ID, creditScore: 640, recordedAt: '2025-03-15T09:00:00.000Z', month: 'Mar', remarks: 'Card balance reduced' },
      { id: 'ch-4', userId: DEMO_USER_ID, creditScore: 645, recordedAt: '2025-04-15T09:00:00.000Z', month: 'Apr', remarks: 'Consistent on-time records' },
      { id: 'ch-5', userId: DEMO_USER_ID, creditScore: 648, recordedAt: '2025-05-15T09:00:00.000Z', month: 'May', remarks: 'No new inquiries' },
      { id: 'ch-6', userId: DEMO_USER_ID, creditScore: 650, recordedAt: '2025-06-15T09:00:00.000Z', month: 'Jun', remarks: 'Current verified score' }
    ]
  };

  const financialUpdates = {
    [DEMO_USER_ID]: [
      {
        id: 'fu-1',
        userId: DEMO_USER_ID,
        oldDebt: 280000,
        newDebt: 250000,
        debtReduction: 30000,
        oldDti: 23.33,
        newDti: 20.0,
        dtiDelta: -3.33,
        oldUtilization: 42.0,
        newUtilization: 35.0,
        utilizationDelta: -7.0,
        oldScore: 635,
        newScore: 650,
        scoreDelta: 15,
        eventType: 'DEBT_PART_PAYMENT',
        updatedAt: '2025-05-20T14:30:00.000Z'
      }
    ]
  };

  const aiConsultations = {
    [DEMO_USER_ID]: []
  };

  return { users, financialProfiles, creditHistory, financialUpdates, aiConsultations };
}

class ResilientStore {
  constructor() {
    this.seed();
  }

  seed() {
    const s = createFreshSeed();
    this.users = s.users;
    this.financialProfiles = s.financialProfiles;
    this.creditHistory = s.creditHistory;
    this.financialUpdates = s.financialUpdates;
    this.aiConsultations = s.aiConsultations;
  }

  // Users / Profiles
  findUserByEmail(email) {
    return this.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  findUserById(id) {
    return this.users.find(u => u.id === id);
  }

  createUser(userData) {
    const id = userData.id || `user-${Date.now()}`;
    const newUser = {
      id,
      name: userData.name,
      email: userData.email,
      passwordHash: userData.passwordHash || 'plain_hashed',
      createdAt: new Date().toISOString()
    };
    this.users.push(newUser);
    return newUser;
  }

  // Financial Profile
  getFinancialProfile(userId) {
    return this.financialProfiles[userId] || null;
  }

  saveFinancialProfile(userId, data) {
    const calculated = calculateFinancialMetrics(data);
    const existing = this.financialProfiles[userId];

    const profile = {
      id: existing ? existing.id : `prof-${Date.now()}`,
      userId,
      ...calculated,
      createdAt: existing ? existing.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.financialProfiles[userId] = profile;

    // Also ensure credit history has at least current score
    if (!this.creditHistory[userId]) {
      this.creditHistory[userId] = [];
    }
    const history = this.creditHistory[userId];
    if (history.length === 0 || history[history.length - 1].creditScore !== calculated.creditScore) {
      const now = new Date();
      history.push({
        id: `ch-${Date.now()}`,
        userId,
        creditScore: calculated.creditScore,
        recordedAt: now.toISOString(),
        month: now.toLocaleString('en-US', { month: 'short' }),
        remarks: 'Assessment / Profile Sync'
      });
    }

    return profile;
  }

  updateFinancialProfile(userId, newData, eventType = 'FINANCIAL_UPDATE') {
    const current = this.financialProfiles[userId] || calculateFinancialMetrics({});
    const updatedMetrics = calculateFinancialMetrics({
      ...current,
      ...newData
    });

    const oldDebt = current.totalDebt;
    const newDebt = updatedMetrics.totalDebt;
    const oldDti = current.dtiRatio;
    const newDti = updatedMetrics.dtiRatio;
    const oldUtil = current.creditUtilization;
    const newUtil = updatedMetrics.creditUtilization;
    const oldScore = current.creditScore;
    const newScore = updatedMetrics.creditScore;

    // Update profile
    const updatedProfile = {
      ...current,
      ...updatedMetrics,
      updatedAt: new Date().toISOString()
    };
    this.financialProfiles[userId] = updatedProfile;

    // Log to financial_updates
    if (!this.financialUpdates[userId]) {
      this.financialUpdates[userId] = [];
    }
    const updateRecord = {
      id: `fu-${Date.now()}`,
      userId,
      oldDebt,
      newDebt,
      debtReduction: oldDebt - newDebt,
      oldDti,
      newDti,
      dtiDelta: Number((newDti - oldDti).toFixed(2)),
      oldUtilization: oldUtil,
      newUtilization: newUtil,
      utilizationDelta: Number((newUtil - oldUtil).toFixed(2)),
      oldScore,
      newScore,
      scoreDelta: newScore - oldScore,
      eventType,
      updatedAt: new Date().toISOString()
    };
    this.financialUpdates[userId].unshift(updateRecord);

    // If score changed, log to credit_history
    if (newScore !== oldScore) {
      if (!this.creditHistory[userId]) this.creditHistory[userId] = [];
      const now = new Date();
      this.creditHistory[userId].push({
        id: `ch-${Date.now()}`,
        userId,
        creditScore: newScore,
        recordedAt: now.toISOString(),
        month: now.toLocaleString('en-US', { month: 'short' }),
        remarks: `Updated after ${eventType.toLowerCase().replace('_', ' ')}`
      });
    }

    return {
      profile: updatedProfile,
      updateRecord
    };
  }

  // Credit History
  getCreditHistory(userId) {
    return this.creditHistory[userId] || [];
  }

  addCreditHistory(userId, score, remarks = 'Manual entry') {
    if (!this.creditHistory[userId]) this.creditHistory[userId] = [];
    const now = new Date();
    const record = {
      id: `ch-${Date.now()}`,
      userId,
      creditScore: score,
      recordedAt: now.toISOString(),
      month: now.toLocaleString('en-US', { month: 'short' }),
      remarks
    };
    this.creditHistory[userId].push(record);
    return record;
  }

  // Financial Updates
  getFinancialUpdates(userId) {
    return this.financialUpdates[userId] || [];
  }

  // AI Consultations
  saveAiConsultation(userId, snapshot, aiAnalysis, actionPlan) {
    if (!this.aiConsultations[userId]) this.aiConsultations[userId] = [];
    const record = {
      id: `ai-${Date.now()}`,
      userId,
      financialSnapshot: snapshot,
      aiAnalysis,
      actionPlan,
      createdAt: new Date().toISOString()
    };
    this.aiConsultations[userId].unshift(record);
    return record;
  }

  getAiConsultations(userId) {
    return this.aiConsultations[userId] || [];
  }

  resetDemo() {
    this.seed();
    return this.financialProfiles[DEMO_USER_ID];
  }
}

export const store = new ResilientStore();
export const DEMO_USER = {
  id: DEMO_USER_ID,
  name: 'Rahul Sharma',
  email: 'rahul.sharma@example.com'
};
