import express from 'express';
import jwt from 'jsonwebtoken';
import { DEMO_USER, store } from '../services/store.js';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'finhealth-secure-secret-key-3f6078db';

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, confirmPassword } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'All fields are required.'
      });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({
        success: false,
        message: 'Passwords do not match.'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.'
      });
    }

    // Check existing
    const existing = store.findUserByEmail(email);
    if (existing) {
      return res.status(400).json({
        success: false,
        message: 'An account with this email already exists. Please log in.'
      });
    }

    // Create user
    const newUser = store.createUser({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      passwordHash: 'dummy_hash_' + Date.now()
    });

    const token = jwt.sign(
      { id: newUser.id, name: newUser.name, email: newUser.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.status(201).json({
      success: true,
      message: 'Registration successful! Proceeding to financial assessment.',
      token,
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email
      }
    });
  } catch (err) {
    console.error('Registration error:', err);
    return res.status(500).json({
      success: false,
      message: 'Something went wrong during registration. Please try again.'
    });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required.'
      });
    }

    const cleanEmail = email.trim().toLowerCase();

    // Demo fast login
    if (cleanEmail === DEMO_USER.email.toLowerCase()) {
      const token = jwt.sign(
        { id: DEMO_USER.id, name: DEMO_USER.name, email: DEMO_USER.email },
        JWT_SECRET,
        { expiresIn: '7d' }
      );
      return res.json({
        success: true,
        message: 'Logged in as Demo User (Rahul Sharma)',
        token,
        user: DEMO_USER,
        isDemo: true
      });
    }

    const user = store.findUserByEmail(cleanEmail);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.'
      });
    }

    const token = jwt.sign(
      { id: user.id, name: user.name, email: user.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.json({
      success: true,
      message: 'Login successful.',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({
      success: false,
      message: 'Something went wrong during login. Please try again.'
    });
  }
});

// GET /api/profile
router.get('/profile', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  }
  const token = authHeader.replace('Bearer ', '');
  if (token === 'demo-token') {
    return res.json({ success: true, user: DEMO_USER });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = store.findUserById(decoded.id) || decoded;
    return res.json({ success: true, user });
  } catch (e) {
    return res.status(401).json({ success: false, message: 'Invalid session token' });
  }
});

export default router;
