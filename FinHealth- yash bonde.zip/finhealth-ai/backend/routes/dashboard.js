import express from 'express';
import { authenticateUser } from '../middleware/auth.js';
import { dataService } from '../services/supabaseService.js';
import { DEMO_USER, store } from '../services/store.js';

const router = express.Router();

// GET /api/dashboard
router.get('/dashboard', authenticateUser, async (req, res) => {
  try {
    const userId = req.user.id;
    let profile = await dataService.getFinancialProfile(userId);

    // If profile not found for demo user, seed default
    if (!profile && userId === DEMO_USER.id) {
      store.seed();
      profile = await dataService.getFinancialProfile(userId);
    }

    if (!profile) {
      return res.json({
        success: true,
        hasProfile: false,
        user: req.user
      });
    }

    const history = await dataService.getCreditHistory(userId);
    const updates = await dataService.getFinancialUpdates(userId);

    // Donut chart data for credit utilization
    const creditDonut = {
      usedCredit: profile.creditCardOutstanding,
      availableCredit: profile.availableCredit,
      totalLimit: profile.creditLimit,
      utilizationPercentage: profile.creditUtilization
    };

    return res.json({
      success: true,
      hasProfile: true,
      user: req.user,
      profile,
      creditDonut,
      creditHistoryPreview: history.slice(-6),
      recentUpdates: updates.slice(0, 5)
    });
  } catch (err) {
    console.error('Dashboard error:', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to load dashboard data.'
    });
  }
});

// POST /api/demo/reset
router.post('/demo/reset', (req, res) => {
  try {
    const profile = store.resetDemo();
    return res.json({
      success: true,
      message: 'Demo state reset to initial Rahul Sharma baseline (Score: 650, Debt: ₹2,50,000, DTI: 20%).',
      profile
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Failed to reset demo state.' });
  }
});

// POST /api/demo/simulate-repayment
// Directly executes Requirement #24: updates debt from ₹2,50,000 to ₹1,50,000
router.post('/demo/simulate-repayment', authenticateUser, async (req, res) => {
  try {
    const userId = req.user.id;
    const current = await dataService.getFinancialProfile(userId) || {};

    // Lower total debt from 2,50,000 to 1,50,000, reduce EMI from 12,000 to 8,000, lower card from 35,000 to 15,000, boost score from 650 to 685!
    const updatedData = {
      totalDebt: 150000,
      monthlyEmi: 8000,
      creditCardOutstanding: 15000,
      creditScore: 685
    };

    const result = await dataService.updateFinancialProfile(userId, updatedData, 'LOAN_PART_REPAYMENT_DEMO');

    return res.json({
      success: true,
      message: 'Debt part-payment of ₹1,00,000 simulated! DTI dropped to 13.33%, Credit score improved to 685.',
      profile: result.profile,
      updateRecord: result.updateRecord
    });
  } catch (err) {
    console.error('Simulate error:', err);
    return res.status(500).json({ success: false, message: 'Simulation failed.' });
  }
});

export default router;
