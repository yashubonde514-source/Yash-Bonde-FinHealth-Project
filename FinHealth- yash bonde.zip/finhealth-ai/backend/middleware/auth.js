import jwt from 'jsonwebtoken';
import { DEMO_USER, store } from '../services/store.js';

const JWT_SECRET = process.env.JWT_SECRET || 'finhealth-secure-secret-key-3f6078db';

export function authenticateUser(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    // If no header, check if query param or demo mode
    return res.status(401).json({
      success: false,
      message: 'Authentication token missing. Please log in.'
    });
  }

  const token = authHeader.startsWith('Bearer ')
    ? authHeader.slice(7)
    : authHeader;

  // Demo user fast-pass
  if (token === 'demo-token' || token === DEMO_USER.id) {
    req.user = DEMO_USER;
    return next();
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = store.findUserById(decoded.id) || {
      id: decoded.id,
      name: decoded.name || 'User',
      email: decoded.email
    };
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired session. Please log in again.'
    });
  }
}
