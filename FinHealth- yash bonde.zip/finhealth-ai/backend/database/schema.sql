-- =========================================================================
-- FinHealth AI - Database Schema (Supabase / PostgreSQL)
-- Description: Tables, Foreign Keys, Indexes, and Row Level Security (RLS)
-- =========================================================================

-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Profiles Table (Extends Supabase auth.users or standalone users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Financial Profiles Table
CREATE TABLE IF NOT EXISTS public.financial_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL,
    credit_score INTEGER NOT NULL CHECK (credit_score >= 300 AND credit_score <= 900),
    monthly_income NUMERIC(12, 2) NOT NULL CHECK (monthly_income >= 0),
    monthly_expenses NUMERIC(12, 2) NOT NULL CHECK (monthly_expenses >= 0),
    total_debt NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (total_debt >= 0),
    monthly_emi NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (monthly_emi >= 0),
    credit_limit NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (credit_limit >= 0),
    credit_card_outstanding NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (credit_card_outstanding >= 0),
    active_loans_count INTEGER NOT NULL DEFAULT 0 CHECK (active_loans_count >= 0),
    credit_utilization NUMERIC(6, 2) NOT NULL DEFAULT 0,
    dti_ratio NUMERIC(6, 2) NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Credit History Table
CREATE TABLE IF NOT EXISTS public.credit_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL,
    credit_score INTEGER NOT NULL CHECK (credit_score >= 300 AND credit_score <= 900),
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    remarks VARCHAR(255) DEFAULT 'Periodic Update'
);

-- 4. Financial Updates Table (Audit trail of improvements & recalculations)
CREATE TABLE IF NOT EXISTS public.financial_updates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL,
    old_debt NUMERIC(12, 2) NOT NULL,
    new_debt NUMERIC(12, 2) NOT NULL,
    old_dti NUMERIC(6, 2) NOT NULL,
    new_dti NUMERIC(6, 2) NOT NULL,
    old_utilization NUMERIC(6, 2) NOT NULL,
    new_utilization NUMERIC(6, 2) NOT NULL,
    old_score INTEGER,
    new_score INTEGER,
    event_type VARCHAR(100) DEFAULT 'DEBT_REDUCTION',
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. AI Consultations Table
CREATE TABLE IF NOT EXISTS public.ai_consultations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL,
    financial_snapshot JSONB NOT NULL,
    ai_analysis JSONB NOT NULL,
    action_plan JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_financial_profiles_user ON public.financial_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_credit_history_user_date ON public.credit_history(user_id, recorded_at);
CREATE INDEX IF NOT EXISTS idx_financial_updates_user ON public.financial_updates(user_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_ai_consultations_user ON public.ai_consultations(user_id, created_at);

-- =========================================================================
-- Row Level Security (RLS) Policies
-- Ensure users can only read/write their own records
-- =========================================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.financial_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.credit_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.financial_updates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_consultations ENABLE ROW LEVEL SECURITY;

-- Profiles: Users can view and update their own profile
CREATE POLICY "Users can view own profile" 
    ON public.profiles FOR SELECT 
    USING (auth.uid() = user_id OR auth.uid() = id);

CREATE POLICY "Users can update own profile" 
    ON public.profiles FOR UPDATE 
    USING (auth.uid() = user_id OR auth.uid() = id);

-- Financial Profiles
CREATE POLICY "Users can view own financial profile" 
    ON public.financial_profiles FOR SELECT 
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own financial profile" 
    ON public.financial_profiles FOR INSERT 
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own financial profile" 
    ON public.financial_profiles FOR UPDATE 
    USING (auth.uid() = user_id);

-- Credit History
CREATE POLICY "Users can view own credit history" 
    ON public.credit_history FOR SELECT 
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own credit history" 
    ON public.credit_history FOR INSERT 
    WITH CHECK (auth.uid() = user_id);

-- Financial Updates
CREATE POLICY "Users can view own updates" 
    ON public.financial_updates FOR SELECT 
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own updates" 
    ON public.financial_updates FOR INSERT 
    WITH CHECK (auth.uid() = user_id);

-- AI Consultations
CREATE POLICY "Users can view own AI consultations" 
    ON public.ai_consultations FOR SELECT 
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own AI consultations" 
    ON public.ai_consultations FOR INSERT 
    WITH CHECK (auth.uid() = user_id);
