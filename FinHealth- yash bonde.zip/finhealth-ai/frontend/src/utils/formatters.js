/**
 * Indian Rupee & Financial Health Formatting Utilities
 */

// Formats number to Indian Rupee currency: e.g. 250000 -> ₹2,50,000
export function formatINR(amount) {
  if (amount === undefined || amount === null || isNaN(amount)) return '₹0';
  const num = Math.round(Number(amount));
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(num);
}

// Compact Indian format: e.g. 250000 -> ₹2.50 Lakh, 10000000 -> ₹1.00 Cr
export function formatCompactINR(amount) {
  if (amount === undefined || amount === null || isNaN(amount)) return '₹0';
  const num = Number(amount);
  if (num >= 10000000) {
    return `₹${(num / 10000000).toFixed(2)} Cr`;
  }
  if (num >= 100000) {
    return `₹${(num / 100000).toFixed(2)} Lakh`;
  }
  if (num >= 1000) {
    return `₹${(num / 1000).toFixed(1)}k`;
  }
  return formatINR(num);
}

// Credit score category and metadata
export function getScoreCategoryDetails(score) {
  const s = Number(score) || 650;
  if (s >= 800) {
    return {
      category: 'Excellent',
      color: 'text-emerald-700 bg-emerald-50 border-emerald-200',
      badgeColor: 'bg-emerald-600 text-white',
      ringColor: '#059669',
      advice: 'Prime borrowing tier. Eligible for the lowest interest rates and premium credit cards in India.'
    };
  }
  if (s >= 740) {
    return {
      category: 'Very Good',
      color: 'text-teal-700 bg-teal-50 border-teal-200',
      badgeColor: 'bg-teal-600 text-white',
      ringColor: '#0d9488',
      advice: 'Strong credit profile. Quick loan approvals from major banks (SBI, HDFC, ICICI).'
    };
  }
  if (s >= 670) {
    return {
      category: 'Good',
      color: 'text-blue-700 bg-blue-50 border-blue-200',
      badgeColor: 'bg-blue-600 text-white',
      ringColor: '#2563eb',
      advice: 'Acceptable credit standing. Eligible for standard rates; maintain regular payments to cross 740.'
    };
  }
  if (s >= 580) {
    return {
      category: 'Fair',
      color: 'text-amber-700 bg-amber-50 border-amber-200',
      badgeColor: 'bg-amber-600 text-white',
      ringColor: '#d97706',
      advice: 'Moderate risk category. Higher interest rates may apply; focus on lowering card balances and zero delays.'
    };
  }
  return {
    category: 'Poor',
    color: 'text-rose-700 bg-rose-50 border-rose-200',
    badgeColor: 'bg-rose-600 text-white',
    ringColor: '#e11d48',
    advice: 'High risk credit profile. High probability of loan rejection; initiate debt consolidation and credit rebuilding.'
  };
}

// DTI Ratio Category
export function getDtiCategoryDetails(dti) {
  const val = Number(dti) || 0;
  if (val <= 20) {
    return {
      category: 'Excellent',
      label: 'Healthy & Low Risk',
      color: 'text-emerald-700 bg-emerald-50 border-emerald-200',
      status: 'Healthy',
      textColor: 'text-emerald-600',
      barColor: 'bg-emerald-500'
    };
  }
  if (val <= 35) {
    return {
      category: 'Good',
      label: 'Manageable Debt',
      color: 'text-blue-700 bg-blue-50 border-blue-200',
      status: 'Manageable',
      textColor: 'text-blue-600',
      barColor: 'bg-blue-500'
    };
  }
  if (val <= 49) {
    return {
      category: 'Moderate',
      label: 'Elevated Burden',
      color: 'text-amber-700 bg-amber-50 border-amber-200',
      status: 'Caution',
      textColor: 'text-amber-600',
      barColor: 'bg-amber-500'
    };
  }
  return {
    category: 'High Risk',
    label: 'Critical Debt Overload',
    color: 'text-rose-700 bg-rose-50 border-rose-200',
    status: 'Critical',
    textColor: 'text-rose-600',
    barColor: 'bg-rose-500'
  };
}

// Credit Utilization category
export function getUtilizationCategory(util) {
  const val = Number(util) || 0;
  if (val <= 30) {
    return {
      status: 'Optimal (<30%)',
      color: 'text-emerald-600',
      bg: 'bg-emerald-50 border-emerald-200'
    };
  }
  if (val <= 50) {
    return {
      status: 'Moderate (30-50%)',
      color: 'text-amber-600',
      bg: 'bg-amber-50 border-amber-200'
    };
  }
  return {
    status: 'High (>50%)',
    color: 'text-rose-600',
    bg: 'bg-rose-50 border-rose-200'
  };
}
