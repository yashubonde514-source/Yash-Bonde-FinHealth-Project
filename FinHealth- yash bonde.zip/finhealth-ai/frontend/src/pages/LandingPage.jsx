import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { 
  ShieldCheck, 
  Sparkles, 
  TrendingUp, 
  PieChart, 
  Lock, 
  ArrowRight, 
  CheckCircle2, 
  Award, 
  Calculator, 
  FileText,
  BadgePercent,
  Check
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function LandingPage() {
  const { loginAsDemo } = useAuth();
  const navigate = useNavigate();

  const handleDemoLaunch = async () => {
    await loginAsDemo(true);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-emerald-500 selection:text-white">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28 border-b border-slate-200 bg-gradient-to-b from-white via-slate-50 to-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            {/* Pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold mb-6 shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Tailored for Indian Salaried & Self-Employed Users</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-tight">
              Master Your Credit Health with{' '}
              <span className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 bg-clip-text text-transparent">
                FinHealth AI
              </span>
            </h1>

            <p className="mt-6 text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl mx-auto">
              Empowering Indian borrowers to monitor CIBIL scores, optimize Debt-to-Income (DTI) ratios, and receive personalized, actionable 5-step financial recovery roadmaps powered by Google Gemini.
            </p>

            {/* CTAs */}
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5">
              <Link
                to="/register"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl bg-emerald-600 text-white font-bold text-base hover:bg-emerald-700 shadow-lg shadow-emerald-600/30 transition-all hover:-translate-y-0.5"
              >
                <span>Get Started Free</span>
                <ArrowRight className="w-4 h-4" />
              </Link>

              <button
                onClick={handleDemoLaunch}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white text-slate-800 font-bold text-base border border-slate-300 hover:bg-slate-50 hover:border-slate-400 shadow-sm transition-all"
              >
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>Try Instant Demo Mode</span>
              </button>
            </div>

            {/* Trust bullet indicators */}
            <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-500 font-medium">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Zero Bank Password or OTP required</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>RBI & CIBIL 300-900 benchmarked</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Supabase PostgreSQL + RLS secured</span>
              </div>
            </div>
          </div>

          {/* Interactive Feature Snapshot Preview */}
          <div className="mt-14 max-w-5xl mx-auto rounded-3xl bg-slate-900 p-2 sm:p-4 shadow-2xl border border-slate-800">
            <div className="rounded-2xl bg-slate-950 p-6 sm:p-8 text-white grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
                <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block">Credit Score Status</span>
                <div className="text-3xl font-extrabold text-emerald-400 mt-2">742 <span className="text-xs text-slate-400 font-normal">/ 900</span></div>
                <div className="mt-2 inline-block px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold">
                  Good (CIBIL Scale)
                </div>
                <p className="mt-3 text-xs text-slate-400">Prime rates for personal & home loans.</p>
              </div>

              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
                <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block">Debt-to-Income (DTI)</span>
                <div className="text-3xl font-extrabold text-teal-400 mt-2">20.0%</div>
                <div className="mt-2 inline-block px-2.5 py-0.5 rounded-full bg-teal-500/20 text-teal-300 text-xs font-semibold">
                  Healthy & Low Risk
                </div>
                <p className="mt-3 text-xs text-slate-400">Monthly EMI ₹12,000 on ₹60,000 gross salary.</p>
              </div>

              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
                <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block">Credit Utilization</span>
                <div className="text-3xl font-extrabold text-amber-400 mt-2">35.0%</div>
                <div className="mt-2 inline-block px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-xs font-semibold">
                  Slightly Above 30%
                </div>
                <p className="mt-3 text-xs text-slate-400">₹35k used out of ₹1,00,000 credit limit.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-xs font-bold text-emerald-600 uppercase tracking-widest">
              Core Capabilities
            </h2>
            <h3 className="mt-2 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Designed for Indian Financial Realities
            </h3>
            <p className="mt-4 text-slate-600 text-sm sm:text-base">
              From EMI burdens and credit card revolving interest to bureau disputes, FinHealth AI delivers holistic financial well-being.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-7 rounded-2xl bg-slate-50 border border-slate-100 hover:border-emerald-200 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-5">
                <Calculator className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-slate-900">Automated DTI Calculation</h4>
              <p className="mt-2.5 text-sm text-slate-600 leading-relaxed">
                Calculates your exact Debt-to-Income ratio from your monthly EMI and gross income, categorizing it under RBI prudent banking limits.
              </p>
            </div>

            <div className="p-7 rounded-2xl bg-slate-50 border border-slate-100 hover:border-emerald-200 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center mb-5">
                <Sparkles className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-slate-900">AI Financial Advisor</h4>
              <p className="mt-2.5 text-sm text-slate-600 leading-relaxed">
                Powered by Google Gemini to analyze your exact portfolio and generate an educational 5-step action plan for score boosting.
              </p>
            </div>

            <div className="p-7 rounded-2xl bg-slate-50 border border-slate-100 hover:border-emerald-200 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center mb-5">
                <TrendingUp className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-slate-900">Live Credit Trajectory</h4>
              <p className="mt-2.5 text-sm text-slate-600 leading-relaxed">
                Interactive charts track score progression over 3M, 6M, 1Y, and all-time intervals, visualizing milestones as you pay down debt.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 bg-slate-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-xs font-bold text-emerald-600 uppercase tracking-widest">
              Simple 4-Step Process
            </h2>
            <h3 className="mt-2 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              How FinHealth AI Works
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { num: '01', title: 'Register & Profile', desc: 'Create your account in seconds without providing sensitive banking passwords.' },
              { num: '02', title: 'Financial Assessment', desc: 'Enter income, monthly expenses, existing EMIs, and credit limit.' },
              { num: '03', title: 'Consult Gemini AI', desc: 'Get automated DTI analysis and an actionable 5-step debt management plan.' },
              { num: '04', title: 'Update & Recalculate', desc: 'Log part-payments and instantly watch your debt and DTI improve.' }
            ].map((step) => (
              <div key={step.num} className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm relative">
                <span className="text-3xl font-black text-slate-200 block mb-2 font-mono">
                  {step.num}
                </span>
                <h4 className="text-base font-bold text-slate-900 mb-2">{step.title}</h4>
                <p className="text-xs text-slate-600 leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="benefits" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-xs font-bold text-emerald-600 uppercase tracking-widest">
                Why Indian Users Choose FinHealth AI
              </h2>
              <h3 className="mt-2 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
                Empowerment through transparent financial analytics
              </h3>
              <p className="mt-4 text-slate-600 text-sm sm:text-base leading-relaxed">
                Unlike complex banking portals, FinHealth AI translates numbers into clear indicators, helping you qualify for prime home loans, reduce card interest traps, and build generational wealth.
              </p>

              <div className="mt-8 space-y-4">
                {[
                  'Indian Rupee (₹) formatting & Indian numbering system throughout',
                  'Instant CIBIL category grading: Poor, Fair, Good, Very Good, Excellent',
                  'Simulated loan pre-payment tools to test "what-if" scenarios',
                  'Educational disclaimers ensuring zero misleading promises or false guarantees'
                ].map((item, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-sm text-slate-700 font-medium">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-tr from-slate-900 to-slate-800 p-8 rounded-3xl text-white shadow-xl border border-slate-700">
              <div className="flex items-center gap-3 pb-6 border-b border-slate-700">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Award className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-base">Ready for Demonstration</h4>
                  <p className="text-xs text-slate-400">Pre-loaded with sample Indian persona Rahul Sharma</p>
                </div>
              </div>

              <div className="py-6 space-y-3 text-xs text-slate-300">
                <p>• Monthly Gross Income: <strong className="text-white">₹60,000</strong></p>
                <p>• Total Outstanding Debt: <strong className="text-white">₹2,50,000</strong></p>
                <p>• Monthly EMI: <strong className="text-white">₹12,000 (DTI: 20%)</strong></p>
                <p>• Credit Card Balance: <strong className="text-white">₹35,000 / ₹1,00,000 Limit</strong></p>
              </div>

              <button
                onClick={handleDemoLaunch}
                className="w-full py-3 rounded-xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-500 shadow-md shadow-emerald-600/30 transition-all flex items-center justify-center gap-2"
              >
                <span>Launch Rahul Sharma Demo Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto bg-slate-900 text-slate-400 text-xs py-10 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span className="font-bold text-white text-sm">FinHealth AI</span>
            <span>— Personal Financial Health Advisor (India)</span>
          </div>
          <p className="text-center sm:text-right text-[11px] text-slate-400">
            AI-generated insights are for educational purposes and do not replace certified financial advice.
          </p>
        </div>
      </footer>
    </div>
  );
}
