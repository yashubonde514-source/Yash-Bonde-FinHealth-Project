import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import { formatINR, getDtiCategoryDetails, getScoreCategoryDetails } from '../utils/formatters';
import { 
  Calculator, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  Sparkles, 
  HelpCircle,
  Percent,
  ShieldAlert
} from 'lucide-react';

export default function FinancialAssessmentPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    creditScore: 650,
    monthlyIncome: 60000,
    monthlyExpenses: 35000,
    totalDebt: 250000,
    monthlyEmi: 12000,
    creditLimit: 100000,
    creditCardOutstanding: 35000,
    activeLoansCount: 2
  });

  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Live real-time calculations as user types
  const liveMetrics = useMemo(() => {
    const income = Math.max(0, Number(formData.monthlyIncome) || 0);
    const emi = Math.max(0, Number(formData.monthlyEmi) || 0);
    const limit = Math.max(0, Number(formData.creditLimit) || 0);
    const cardOutstanding = Math.max(0, Number(formData.creditCardOutstanding) || 0);
    const score = Math.min(900, Math.max(300, Number(formData.creditScore) || 650));

    // DTI = (Total Monthly Debt Payments / Gross Monthly Income) * 100
    const dtiRatio = income > 0 ? Number(((emi / income) * 100).toFixed(1)) : 0;
    const dtiCategory = getDtiCategoryDetails(dtiRatio);
    const scoreCategory = getScoreCategoryDetails(score);

    // Credit Utilization
    const creditUtilization = limit > 0 ? Number(((cardOutstanding / limit) * 100).toFixed(1)) : 0;

    return {
      dtiRatio,
      dtiCategory,
      scoreCategory,
      creditUtilization
    };
  }, [formData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    const num = Number(value);
    setFormData((prev) => ({
      ...prev,
      [name]: isNaN(num) ? 0 : num
    }));
    if (error) setError('');
  };

  const handlePreloadDemo = () => {
    setFormData({
      creditScore: 650,
      monthlyIncome: 60000,
      monthlyExpenses: 35000,
      totalDebt: 250000,
      monthlyEmi: 12000,
      creditLimit: 100000,
      creditCardOutstanding: 35000,
      activeLoansCount: 2
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validation
    if (formData.monthlyIncome < 0 || formData.monthlyExpenses < 0) {
      return setError('Income and Expenses cannot be negative.');
    }
    if (formData.totalDebt < 0 || formData.monthlyEmi < 0) {
      return setError('Loan debt and EMI cannot be negative.');
    }
    if (formData.creditScore < 300 || formData.creditScore > 900) {
      return setError('Credit score must be between 300 and 900 (Indian CIBIL standard).');
    }
    if (formData.creditLimit < 0 || formData.creditCardOutstanding < 0) {
      return setError('Credit limits cannot be negative.');
    }

    setIsSubmitting(true);
    try {
      const res = await api.saveFinancialProfile(formData);
      if (res.success) {
        navigate('/dashboard');
      } else {
        setError(res.message || 'Failed to save financial profile.');
      }
    } catch (err) {
      setError(err.message || 'Something went wrong. Please check your inputs.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 uppercase tracking-widest bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 mb-2">
              <Calculator className="w-3.5 h-3.5 text-emerald-600" />
              <span>Step 2 of 2: Onboarding Assessment</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Personal Financial Assessment
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Provide your income, existing loan commitments, and credit profile in Indian Rupees (₹).
            </p>
          </div>

          <button
            type="button"
            onClick={handlePreloadDemo}
            className="self-start sm:self-auto inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>Pre-fill Rahul Sharma Data</span>
          </button>
        </div>

        {error && (
          <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form (2 cols on large screen) */}
          <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Credit Score Input */}
              <div className="bg-slate-50/70 p-4 rounded-2xl border border-slate-100">
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Current Credit Score (CIBIL / Experian)
                  </label>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${liveMetrics.scoreCategory.badgeColor}`}>
                    {liveMetrics.scoreCategory.category}
                  </span>
                </div>
                <div className="relative mt-2">
                  <input
                    type="number"
                    name="creditScore"
                    min="300"
                    max="900"
                    value={formData.creditScore}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <div className="absolute inset-y-0 right-3 flex items-center text-xs text-slate-400 pointer-events-none">
                    300 – 900
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 mt-1.5">
                  Check your latest bureau report or estimate based on past credit lines.
                </p>
              </div>

              {/* Monthly Income & Expenses */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Monthly Gross Income (₹)
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-3 flex items-center text-sm font-semibold text-slate-400">
                      ₹
                    </span>
                    <input
                      type="number"
                      name="monthlyIncome"
                      min="0"
                      value={formData.monthlyIncome}
                      onChange={handleChange}
                      placeholder="60000"
                      required
                      className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    {formatINR(formData.monthlyIncome)}/month
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Monthly Living Expenses (₹)
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-3 flex items-center text-sm font-semibold text-slate-400">
                      ₹
                    </span>
                    <input
                      type="number"
                      name="monthlyExpenses"
                      min="0"
                      value={formData.monthlyExpenses}
                      onChange={handleChange}
                      placeholder="35000"
                      required
                      className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    {formatINR(formData.monthlyExpenses)}/month
                  </span>
                </div>
              </div>

              {/* Debt & EMI */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Total Outstanding Debt (₹)
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-3 flex items-center text-sm font-semibold text-slate-400">
                      ₹
                    </span>
                    <input
                      type="number"
                      name="totalDebt"
                      min="0"
                      value={formData.totalDebt}
                      onChange={handleChange}
                      placeholder="250000"
                      required
                      className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    {formatINR(formData.totalDebt)} total principal
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Monthly Loan EMI (₹)
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-3 flex items-center text-sm font-semibold text-slate-400">
                      ₹
                    </span>
                    <input
                      type="number"
                      name="monthlyEmi"
                      min="0"
                      value={formData.monthlyEmi}
                      onChange={handleChange}
                      placeholder="12000"
                      required
                      className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Used to calculate your DTI ratio
                  </span>
                </div>
              </div>

              {/* Credit Limit & Card Balance */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Total Credit Limit (₹)
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-3 flex items-center text-sm font-semibold text-slate-400">
                      ₹
                    </span>
                    <input
                      type="number"
                      name="creditLimit"
                      min="0"
                      value={formData.creditLimit}
                      onChange={handleChange}
                      placeholder="100000"
                      required
                      className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Across all cards
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Credit Card Outstanding (₹)
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-3 flex items-center text-sm font-semibold text-slate-400">
                      ₹
                    </span>
                    <input
                      type="number"
                      name="creditCardOutstanding"
                      min="0"
                      value={formData.creditCardOutstanding}
                      onChange={handleChange}
                      placeholder="35000"
                      required
                      className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Current unpaid balance
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Active Loans Count
                  </label>
                  <input
                    type="number"
                    name="activeLoansCount"
                    min="0"
                    value={formData.activeLoansCount}
                    onChange={handleChange}
                    placeholder="2"
                    required
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Personal, car, home loans
                  </span>
                </div>
              </div>

              {/* Submit button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 px-6 rounded-xl bg-emerald-600 text-white font-bold text-base hover:bg-emerald-700 shadow-md shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <span>{isSubmitting ? 'Calculating & Saving...' : 'Save & Open Financial Dashboard'}</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </form>
          </div>

          {/* Right Column: Live DTI & Health Calculation Preview */}
          <div className="space-y-6">
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Live Metric Preview
                </span>
                <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                  Instant Recalculation
                </span>
              </div>

              {/* DTI Ratio Card */}
              <div className="my-5 p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-500">Debt-to-Income (DTI)</span>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${liveMetrics.dtiCategory.color}`}>
                    {liveMetrics.dtiCategory.category}
                  </span>
                </div>
                <div className="mt-2 text-3xl font-extrabold text-slate-900">
                  {liveMetrics.dtiRatio}%
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-200 h-2.5 rounded-full mt-3 overflow-hidden">
                  <div
                    className={`h-full ${liveMetrics.dtiCategory.barColor} transition-all duration-300`}
                    style={{ width: `${Math.min(100, liveMetrics.dtiRatio)}%` }}
                  />
                </div>

                <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
                  <span>0% (Ideal)</span>
                  <span>35% (Prudent Limit)</span>
                  <span>50%+ (High Risk)</span>
                </div>

                <p className="mt-3 text-xs text-slate-600 leading-relaxed">
                  Formula: ({formatINR(formData.monthlyEmi)} EMI ÷ {formatINR(formData.monthlyIncome)} Income) × 100
                </p>
              </div>

              {/* Credit Utilization Card */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-500">Card Utilization</span>
                  <span className={`text-xs font-bold ${liveMetrics.creditUtilization <= 30 ? 'text-emerald-600' : 'text-amber-600'}`}>
                    {liveMetrics.creditUtilization <= 30 ? 'Healthy (<30%)' : 'High (>30%)'}
                  </span>
                </div>
                <div className="mt-2 text-2xl font-extrabold text-slate-900">
                  {liveMetrics.creditUtilization}%
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full mt-2 overflow-hidden">
                  <div
                    className={`h-full ${liveMetrics.creditUtilization <= 30 ? 'bg-emerald-500' : 'bg-amber-500'} transition-all`}
                    style={{ width: `${Math.min(100, liveMetrics.creditUtilization)}%` }}
                  />
                </div>
              </div>

              {/* RBI Prudence Guideline note */}
              <div className="mt-5 p-3 rounded-xl bg-blue-50/70 border border-blue-100 text-[11px] text-blue-900 leading-relaxed">
                <strong>RBI Prudent Banking Note:</strong> A Debt-to-Income ratio below 35% ensures seamless eligibility for retail home loans and pre-approved personal credit lines in Indian banks.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
