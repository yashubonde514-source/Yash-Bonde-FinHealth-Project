import React, { useState, useEffect } from 'react';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import DemoWalkthroughModal from '../components/DemoWalkthroughModal';
import { api } from '../services/api';
import { formatINR } from '../utils/formatters';
import { 
  Sparkles, 
  RotateCw, 
  CheckCircle2, 
  AlertCircle, 
  ShieldCheck, 
  Check, 
  ArrowRight, 
  Info, 
  Award,
  Zap,
  Target,
  Menu
} from 'lucide-react';

export default function AIAdvisorPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showDemoTour, setShowDemoTour] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [error, setError] = useState('');
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    // Load profile snapshot
    api.getDashboard().then(res => {
      if (res.success && res.profile) {
        setProfile(res.profile);
      }
    }).catch(err => console.error(err));
  }, []);

  const handleGenerateAnalysis = async () => {
    setIsAnalyzing(true);
    setError('');
    try {
      const res = await api.analyzeFinancialHealth(profile);
      if (res.success && res.analysis) {
        setAnalysisResult(res.analysis);
      } else {
        setError(res.message || 'Unable to generate analysis. Please try again.');
      }
    } catch (err) {
      console.error('AI consultation error:', err);
      setError('Connection to AI advisor engine failed. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Helper to render ASCII-style visual progress bar from Requirement #8
  const renderVisualHealthBar = (score = 80) => {
    const totalBlocks = 10;
    const filledBlocks = Math.round((score / 100) * totalBlocks);
    const emptyBlocks = totalBlocks - filledBlocks;
    return (
      <span className="font-mono text-emerald-500 font-bold tracking-widest text-base sm:text-lg">
        {'█'.repeat(filledBlocks)}
        {'░'.repeat(emptyBlocks)} {score}%
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="flex-1 flex flex-col lg:pl-64 transition-all">
        {/* Mobile Header */}
        <div className="flex items-center justify-between lg:hidden px-4 py-2 bg-slate-900 text-white">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white"
          >
            <Menu className="w-6 h-6" />
          </button>
          <span className="font-extrabold text-sm tracking-tight">FinHealth AI Advisor</span>
          <div className="w-6" />
        </div>

        <Header onOpenDemoTour={() => setShowDemoTour(true)} />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto w-full">
          {/* Top Banner */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200 mb-3">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>Google Gemini Personal Finance Engine</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                AI Financial Consultation & Recovery Plan
              </h2>
              <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed">
                Receive customized educational analysis regarding your DTI ratio, CIBIL credit score, and debt commitments benchmarked against Reserve Bank of India (RBI) best practices.
              </p>
            </div>

            <div className="shrink-0">
              <button
                onClick={handleGenerateAnalysis}
                disabled={isAnalyzing}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-emerald-600 text-white font-extrabold text-sm hover:bg-emerald-700 shadow-md shadow-emerald-600/30 transition-all hover:scale-105 active:scale-95 disabled:opacity-50"
              >
                {isAnalyzing ? (
                  <>
                    <RotateCw className="w-4 h-4 animate-spin" />
                    <span>Analyzing Portfolio...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4" />
                    <span>{analysisResult ? 'Regenerate Analysis' : 'Analyze My Financial Health'}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {error && (
            <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* If No Analysis Generated Yet: Intro Placeholder */}
          {!analysisResult && !isAnalyzing && (
            <div className="bg-white rounded-3xl p-10 text-center border border-dashed border-slate-300 max-w-2xl mx-auto my-8">
              <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                Ready to Analyze Your Indian Financial Health
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto mt-2 leading-relaxed">
                Click <strong>"Analyze My Financial Health"</strong> to generate your health score, credit category assessment, key observations, and a tailored 5-step actionable recovery plan.
              </p>
              <button
                onClick={handleGenerateAnalysis}
                className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition-all"
              >
                <span>Run Analysis Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Loading Animation Skeleton */}
          {isAnalyzing && (
            <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm space-y-6 animate-pulse">
              <div className="flex items-center justify-between">
                <div className="h-6 bg-slate-200 rounded w-1/3" />
                <div className="h-6 bg-slate-200 rounded w-24" />
              </div>
              <div className="h-4 bg-slate-100 rounded w-3/4" />
              <div className="h-4 bg-slate-100 rounded w-1/2" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
                <div className="h-24 bg-slate-100 rounded-2xl" />
                <div className="h-24 bg-slate-100 rounded-2xl" />
              </div>
              <div className="h-40 bg-slate-50 rounded-2xl" />
            </div>
          )}

          {/* Requirement #8: AI Response UI (Rendered Analysis) */}
          {analysisResult && !isAnalyzing && (
            <div className="space-y-6 animate-in fade-in duration-300">
              {/* Score & Category Top Summary Card */}
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-6 border-b border-slate-100">
                  {/* Financial Health Progress Indicator */}
                  <div>
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                      Financial Health Rating
                    </span>
                    <div className="mt-2 flex items-baseline gap-3">
                      <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800 shadow-inner">
                        {renderVisualHealthBar(analysisResult.healthScore || 80)}
                      </div>
                    </div>
                    <p className="text-xs text-slate-500 mt-2">
                      Composite benchmark calculated across DTI, CIBIL, card utilization, and liquid savings.
                    </p>
                  </div>

                  {/* Credit Health Tier */}
                  <div>
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                      Credit Health Category
                    </span>
                    <div className="mt-2 flex items-center gap-3">
                      <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                        {analysisResult.creditHealthCategory || 'Good'}
                      </span>
                      <span className="px-3 py-1 text-xs font-bold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                        CIBIL Standard
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-2">
                      Eligible for retail credit facilities across Indian public and private banks.
                    </p>
                  </div>
                </div>

                {/* Narrative Summary */}
                <div className="pt-6">
                  <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2">
                    Executive Summary
                  </h4>
                  <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    {analysisResult.healthSummary}
                  </p>
                </div>
              </div>

              {/* Requirement #8: Key Observations & Credit Health Breakdown */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Key Observations */}
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm">
                  <h3 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2 mb-4">
                    <Target className="w-5 h-5 text-emerald-600" />
                    Key Observations
                  </h3>
                  <ul className="space-y-3">
                    {analysisResult.keyObservations?.map((obs, idx) => (
                      <li key={idx} className="flex items-start gap-3 text-xs sm:text-sm text-slate-700 leading-relaxed">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0 mt-2" />
                        <span>{obs}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Credit Health Specifics & Attention Areas */}
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm">
                  <h3 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2 mb-4">
                    <ShieldCheck className="w-5 h-5 text-teal-600" />
                    Credit Health Diagnostics
                  </h3>

                  <div className="space-y-3 text-xs sm:text-sm">
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <strong className="text-slate-900 block mb-0.5">Credit Utilization:</strong>
                      <span className="text-slate-600">{analysisResult.creditHealth?.creditUtilizationNote}</span>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <strong className="text-slate-900 block mb-0.5">Debt-to-Income (DTI):</strong>
                      <span className="text-slate-600">{analysisResult.creditHealth?.dtiNote}</span>
                    </div>

                    {analysisResult.creditHealth?.attentionAreas?.length > 0 && (
                      <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200">
                        <strong className="text-amber-900 block mb-1">Focus Areas:</strong>
                        <ul className="list-disc list-inside text-xs text-amber-800 space-y-1">
                          {analysisResult.creditHealth.attentionAreas.map((area, i) => (
                            <li key={i}>{area}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Requirement #7 & #8: Your 5-Step Action Plan */}
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                  <div>
                    <h3 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
                      <Award className="w-6 h-6 text-emerald-600" />
                      Your 5-Step Action Plan
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                      Sequential recommendations to reduce interest payments and improve CIBIL credit tier
                    </p>
                  </div>

                  <button
                    onClick={handleGenerateAnalysis}
                    className="self-start sm:self-auto inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                    <span>Regenerate Analysis</span>
                  </button>
                </div>

                {/* 5 Distinct Action Step Cards */}
                <div className="mt-6 space-y-4">
                  {analysisResult.actionPlan?.map((item) => (
                    <div
                      key={item.step}
                      className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-emerald-300 hover:bg-emerald-50/20 transition-all flex flex-col sm:flex-row sm:items-start gap-4"
                    >
                      <div className="w-12 h-12 rounded-xl bg-slate-900 text-emerald-400 font-extrabold text-lg flex items-center justify-center shrink-0 font-mono shadow-sm">
                        0{item.step}
                      </div>

                      <div className="flex-1">
                        <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                          <h4 className="text-base font-bold text-slate-900">
                            {item.title}
                          </h4>
                          <div className="flex items-center gap-2">
                            {item.impact && (
                              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-200">
                                {item.impact} Impact
                              </span>
                            )}
                            {item.timeframe && (
                              <span className="text-[10px] font-medium text-slate-500">
                                {item.timeframe}
                              </span>
                            )}
                          </div>
                        </div>
                        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Requirement #7 & #8: Mandatory Educational Disclaimer */}
              <div className="p-4 rounded-2xl bg-slate-100 border border-slate-200 text-xs text-slate-500 flex items-start gap-3">
                <Info className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  <strong>Important Notice:</strong> {analysisResult.disclaimer || 'AI-generated information is for educational purposes and should not replace professional financial advice. FinHealth AI will never ask for your passwords, OTPs, PINs, or bank account credentials.'}
                </p>
              </div>
            </div>
          )}
        </main>
      </div>

      <DemoWalkthroughModal
        isOpen={showDemoTour}
        onClose={() => setShowDemoTour(false)}
      />
    </div>
  );
}
