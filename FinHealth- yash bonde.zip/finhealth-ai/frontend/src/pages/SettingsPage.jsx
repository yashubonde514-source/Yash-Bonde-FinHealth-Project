import React, { useState, useEffect } from 'react';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import DemoWalkthroughModal from '../components/DemoWalkthroughModal';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { 
  Settings, 
  ShieldCheck, 
  RotateCcw, 
  Key, 
  Database, 
  CheckCircle2, 
  AlertCircle,
  Sparkles,
  Menu
} from 'lucide-react';

export default function SettingsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showDemoTour, setShowDemoTour] = useState(false);
  const { user, isDemo, loginAsDemo } = useAuth();
  const [healthStatus, setHealthStatus] = useState(null);
  const [resetSuccess, setResetSuccess] = useState('');
  const [isResetting, setIsResetting] = useState(false);

  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => setHealthStatus(data))
      .catch((e) => console.error(e));
  }, []);

  const handleResetDemo = async () => {
    setIsResetting(true);
    try {
      await api.resetDemo();
      await loginAsDemo(true);
      setResetSuccess('Demo data reset to initial baseline (Rahul Sharma - Score 650, Debt ₹2,50,000)!');
      setTimeout(() => setResetSuccess(''), 5000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="flex-1 flex flex-col lg:pl-64 transition-all">
        {/* Mobile Header */}
        <div className="flex items-center justify-between lg:hidden px-4 py-2 bg-slate-900 text-white">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white"
          >
            <Menu className="w-6 h-6" />
          </button>
          <span className="font-extrabold text-sm tracking-tight">Settings</span>
          <div className="w-6" />
        </div>

        <Header onOpenDemoTour={() => setShowDemoTour(true)} />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto w-full">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm">
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              Settings & Environment Configuration
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Application runtime diagnostics, security posture, and demo environment controls.
            </p>
          </div>

          {resetSuccess && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{resetSuccess}</span>
            </div>
          )}

          {/* User Profile Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Active User Account
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block font-semibold">Name</span>
                <span className="text-sm font-bold text-slate-900">{user?.name || 'Rahul Sharma'}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block font-semibold">Email</span>
                <span className="text-sm font-bold text-slate-900">{user?.email || 'rahul.sharma@example.com'}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block font-semibold">Currency Standard</span>
                <span className="text-sm font-bold text-slate-900">Indian Rupee (INR - ₹)</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block font-semibold">Bureau Jurisdiction</span>
                <span className="text-sm font-bold text-slate-900">CIBIL / Experian India (300-900)</span>
              </div>
            </div>
          </div>

          {/* Integration Status (Gemini & Supabase) */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Key className="w-4 h-4 text-teal-600" />
              Cloud API & Database Status
            </h3>

            <div className="space-y-3">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-xs text-slate-900">Google Gemini AI Engine</h4>
                  <p className="text-[11px] text-slate-500">
                    Provides personal financial analysis, DTI interpretation, and 5-step action plans.
                  </p>
                </div>
                <span className="px-2.5 py-1 text-xs font-bold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  {healthStatus?.geminiConfigured ? 'Active (API Key Connected)' : 'Active (Indian Advisory Simulation Ready)'}
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-xs text-slate-900">Database Layer (Supabase PostgreSQL)</h4>
                  <p className="text-[11px] text-slate-500">
                    PostgreSQL database with Row Level Security (RLS) policies.
                  </p>
                </div>
                <span className="px-2.5 py-1 text-xs font-bold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  {healthStatus?.supabaseConnected ? 'Supabase Connected' : 'Resilient Local Store Active'}
                </span>
              </div>
            </div>
          </div>

          {/* Reset Demo State Button */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-amber-600" />
                Reset Demo State for Judges
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Restores Rahul Sharma's baseline profile (Score 650, Debt ₹2,50,000, EMI ₹12,000, Limit ₹1,00,000).
              </p>
            </div>

            <button
              onClick={handleResetDemo}
              disabled={isResetting}
              className="px-4 py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs hover:bg-slate-800 transition-all shadow-sm shrink-0"
            >
              {isResetting ? 'Resetting...' : 'Reset to Baseline'}
            </button>
          </div>

          {/* Security Compliance Note */}
          <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-100 text-xs text-emerald-900 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong className="block font-bold mb-1">Zero-Trust Credential Architecture:</strong>
              FinHealth AI does not store or request banking passwords, card PINs, CVVs, or Aadhaar/PAN OTPs. Financial information is processed strictly under user-directed educational parameters.
            </div>
          </div>
        </main>
      </div>

      <DemoWalkthroughModal
        isOpen={showDemoTour}
        onClose={() => setShowDemoTour(false)}
      />
    </div>
  );
}
