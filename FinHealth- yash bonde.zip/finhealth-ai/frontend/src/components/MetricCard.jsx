import React from 'react';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

export default function MetricCard({
  title,
  value,
  subvalue,
  category,
  badgeText,
  badgeColor,
  icon: Icon,
  delta,
  deltaType = 'positive', // 'positive' (good), 'negative' (bad), 'neutral'
  trendText,
  color = 'emerald'
}) {
  return (
    <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
      {/* Decorative top accent line */}
      <div className={`absolute top-0 left-0 right-0 h-1 bg-${color}-500/80 group-hover:h-1.5 transition-all`} />

      <div className="flex items-start justify-between">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
          {title}
        </span>
        {Icon && (
          <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 text-slate-600 group-hover:text-emerald-600 group-hover:bg-emerald-50 transition-colors">
            <Icon className="w-4 h-4" />
          </div>
        )}
      </div>

      <div className="mt-3 flex items-baseline gap-2">
        <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          {value}
        </h3>
        {subvalue && (
          <span className="text-xs text-slate-500 font-medium">
            {subvalue}
          </span>
        )}
      </div>

      {/* Badges and Delta Row */}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        {category && (
          <span className={`inline-flex items-center text-xs font-bold px-2 py-0.5 rounded-full ${badgeColor || 'bg-slate-100 text-slate-700'}`}>
            {category}
          </span>
        )}

        {badgeText && !category && (
          <span className={`inline-flex items-center text-xs font-semibold px-2 py-0.5 rounded-md ${badgeColor || 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>
            {badgeText}
          </span>
        )}

        {delta !== undefined && delta !== null && (
          <div className={`flex items-center text-xs font-semibold ${
            deltaType === 'positive' 
              ? 'text-emerald-600' 
              : deltaType === 'negative' 
                ? 'text-rose-600' 
                : 'text-slate-500'
          }`}>
            {deltaType === 'positive' ? (
              <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
            ) : deltaType === 'negative' ? (
              <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />
            ) : (
              <Minus className="w-3.5 h-3.5 mr-0.5" />
            )}
            <span>{delta}</span>
          </div>
        )}

        {trendText && (
          <span className="text-[11px] text-slate-500 font-normal">
            {trendText}
          </span>
        )}
      </div>
    </div>
  );
}
