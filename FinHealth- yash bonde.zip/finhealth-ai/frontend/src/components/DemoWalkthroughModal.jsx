import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  CheckCircle, 
  ArrowRight, 
  Sparkles, 
  X, 
  TrendingDown, 
  LayoutDashboard, 
  MessageSquare, 
  Clock, 
  RefreshCw 
} from 'lucide-react';
import { api } from '../services/api';

const STEPS = [
  {
    step: 1,
    title: 'Load Sample Indian User (Rahul Sharma)',
    description: 'Pre-seeds a realistic Indian salaried profile: Monthly Income ₹60,000, Living Expenses ₹35,000, Outstanding Debt ₹2,50,000, EMI ₹12,000, Credit Limit ₹1,00,000, Card Balance ₹35,000, Credit Score 650 (Fair).',
    actionText: 'Reset & Load Profile',
    icon: Sparkles,
    route: '/dashboard'
  },
  {
    step: 2,
    title: 'Explore Financial Health Dashboard',
    description: 'Calculates automated DTI (20%), Credit Utilization (35%), Net Monthly Savings (₹13,000), Credit Score Gauge, and Credit Utilization Donut Chart.',
    actionText: 'View Dashboard Metrics',
    icon: LayoutDashboard,
    route: '/dashboard'
  },
  {
    step: 3,
    title: 'Open Gemini AI Financial Advisor',
    description: 'Navigate to the dedicated AI Advisor consultation suite designed specifically with Indian banking and CIBIL rules in mind.',
    actionText: 'Open AI Advisor',
    icon: MessageSquare,
    route: '/ai-advisor'
  },
  {
    step: 4,
    title: 'Generate Personalized 5-Step Action Plan',
    description: 'Execute Gemini analysis returning visual financial health score bar (80%), key observations, credit analysis, and a structured 5-step roadmap.',
    actionText: 'Generate AI Insights',
    icon: Sparkles,
    route: '/ai-advisor'
  },
  {
    step: 5,
    title: 'Review Bureau Credit Score History',
    description: 'Inspect bureau trajectory line chart from 620 to 650, timeframe filtering (3M, 6M, 1Y, All time), and +30 point progress.',
    actionText: 'View Credit History',
    icon: Clock,
    route: '/credit-history'
  },
  {
    step: 6,
    title: 'Simulate ₹1,00,000 Debt Repayment',
    description: 'Execute real-time event: Outstanding debt decreases from ₹2,50,000 to ₹1,50,000, Monthly EMI reduces from ₹12,000 to ₹8,000, and credit card balance clears to ₹15,000.',
    actionText: 'Simulate Repayment Now',
    icon: TrendingDown,
    route: '/update-financial'
  },
  {
    step: 7,
    title: 'View Instant Improvement & Delta Badges',
    description: 'Observe real-time recalculations: DTI drops from 20% to 13.33% (↓ 6.67%), Credit Utilization drops from 35% to 15% (↓ 20%), Credit score ascends to 685 (Good tier).',
    actionText: 'Inspect Live Diffs',
    icon: RefreshCw,
    route: '/update-financial'
  },
  {
    step: 8,
    title: 'Verify Dynamic Dashboard & Charts Refresh',
    description: 'Return to Dashboard to confirm donut chart, summary cards, and history charts instantly reflected the updated financial state without page reload.',
    actionText: 'Return to Updated Dashboard',
    icon: LayoutDashboard,
    route: '/dashboard'
  }
];

export default function DemoWalkthroughModal({ isOpen, onClose, onRefreshData }) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const navigate = useNavigate();

  if (!isOpen) return null;

  const currentStep = STEPS[currentStepIndex];

  const handleStepAction = async () => {
    setIsProcessing(true);
    try {
      if (currentStep.step === 1) {
        await api.resetDemo();
        if (onRefreshData) onRefreshData();
      } else if (currentStep.step === 6) {
        await api.simulateRepayment();
        if (onRefreshData) onRefreshData();
      }

      // Navigate to corresponding route
      if (currentStep.route) {
        navigate(currentStep.route);
      }

      if (currentStepIndex < STEPS.length - 1) {
        setCurrentStepIndex(currentStepIndex + 1);
      } else {
        onClose();
      }
    } catch (e) {
      console.error('Demo step error:', e);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-100 relative overflow-hidden">
        {/* Top header badge */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-sm">
              {currentStep.step} / {STEPS.length}
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">
                Judges & Evaluator Presentation Tour
              </h3>
              <p className="text-xs text-slate-500">
                Interactive demonstration of FinHealth AI features
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stepper Progress Dots */}
        <div className="grid grid-cols-8 gap-1.5 my-4">
          {STEPS.map((s, idx) => (
            <div
              key={s.step}
              onClick={() => setCurrentStepIndex(idx)}
              className={`h-2 rounded-full cursor-pointer transition-all ${
                idx === currentStepIndex
                  ? 'bg-emerald-600 ring-2 ring-emerald-200'
                  : idx < currentStepIndex
                    ? 'bg-emerald-400'
                    : 'bg-slate-200'
              }`}
              title={`Step ${s.step}: ${s.title}`}
            />
          ))}
        </div>

        {/* Current Step Card Content */}
        <div className="my-5 p-5 rounded-2xl bg-slate-50 border border-slate-100">
          <div className="flex items-center gap-2 text-emerald-700 text-xs font-bold uppercase tracking-wider mb-1">
            <currentStep.icon className="w-4 h-4" />
            <span>Step {currentStep.step} of 8</span>
          </div>
          <h4 className="text-lg font-bold text-slate-900 mb-2">
            {currentStep.title}
          </h4>
          <p className="text-sm text-slate-600 leading-relaxed">
            {currentStep.description}
          </p>
        </div>

        {/* Actions Footer */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-100">
          <div className="text-xs text-slate-400">
            Clicking will perform real state transitions.
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            {currentStepIndex > 0 && (
              <button
                onClick={() => setCurrentStepIndex(currentStepIndex - 1)}
                className="px-3.5 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-100"
              >
                Back
              </button>
            )}
            <button
              onClick={handleStepAction}
              disabled={isProcessing}
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-700 shadow-md shadow-emerald-600/30 transition-all disabled:opacity-50 active:scale-95"
            >
              <span>{isProcessing ? 'Processing...' : currentStep.actionText}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
