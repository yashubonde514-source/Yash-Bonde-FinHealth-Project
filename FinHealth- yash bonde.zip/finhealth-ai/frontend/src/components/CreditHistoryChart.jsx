import React, { useState } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { TrendingUp, Calendar, ArrowUpRight, ArrowDownRight, Award } from 'lucide-react';
import { getScoreCategoryDetails } from '../utils/formatters';

const TIME_FILTERS = [
  { id: '3m', label: '3 Months' },
  { id: '6m', label: '6 Months' },
  { id: '1y', label: '1 Year' },
  { id: 'all', label: 'All Time' },
];

export default function CreditHistoryChart({
  history = [],
  onFilterChange,
  activeFilter = '6m',
  stats
}) {
  const [selectedPoint, setSelectedPoint] = useState(null);

  // Fallback data if none provided
  const chartData = history.length > 0 ? history : [
    { month: 'Jan', creditScore: 620 },
    { month: 'Feb', creditScore: 635 },
    { month: 'Mar', creditScore: 640 },
    { month: 'Apr', creditScore: 645 },
    { month: 'May', creditScore: 648 },
    { month: 'Jun', creditScore: 650 },
  ];

  const currentScore = stats?.currentScore || chartData[chartData.length - 1]?.creditScore || 650;
  const previousScore = stats?.previousScore || chartData[0]?.creditScore || 620;
  const scoreChange = stats?.scoreChange !== undefined ? stats.scoreChange : (currentScore - previousScore);
  const percentageImprovement = stats?.percentageImprovement !== undefined
    ? stats.percentageImprovement
    : Number(((scoreChange / previousScore) * 100).toFixed(1));

  const isPositive = scoreChange >= 0;
  const currentCategory = getScoreCategoryDetails(currentScore);

  return (
    <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm">
      {/* Top Header & Timeframe Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
              Credit Score Trajectory
            </h3>
            <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${currentCategory.badgeColor}`}>
              {currentCategory.category}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Verified monthly bureau records (CIBIL / Experian India)
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center p-1 bg-slate-100 rounded-xl self-start sm:self-auto">
          {TIME_FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => onFilterChange && onFilterChange(f.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeFilter === f.id
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Progress Metric Highlights */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-5">
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
          <span className="text-[11px] font-semibold text-slate-500 block">Baseline Score</span>
          <span className="text-xl font-bold text-slate-700">{previousScore}</span>
        </div>

        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
          <span className="text-[11px] font-semibold text-slate-500 block">Current Score</span>
          <span className="text-xl font-extrabold text-slate-900">{currentScore}</span>
        </div>

        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
          <span className="text-[11px] font-semibold text-slate-500 block">Net Point Delta</span>
          <div className={`flex items-center text-xl font-extrabold ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
            {isPositive ? <ArrowUpRight className="w-5 h-5 mr-0.5" /> : <ArrowDownRight className="w-5 h-5 mr-0.5" />}
            <span>{isPositive ? `+${scoreChange}` : scoreChange}</span>
          </div>
        </div>

        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
          <span className="text-[11px] font-semibold text-slate-500 block">Progress Rate</span>
          <span className={`text-xl font-bold ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
            {isPositive ? `+${percentageImprovement}%` : `${percentageImprovement}%`}
          </span>
        </div>
      </div>

      {/* Interactive Line / Area Chart */}
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={chartData}
            margin={{ top: 15, right: 15, left: -20, bottom: 0 }}
          >
            <defs>
              <linearGradient id="scoreAreaGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#059669" stopOpacity={0.25} />
                <stop offset="95%" stopColor="#059669" stopOpacity={0.0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis
              dataKey="month"
              tickLine={false}
              axisLine={{ stroke: '#e2e8f0' }}
              tick={{ fontSize: 12, fill: '#64748b' }}
            />
            <YAxis
              domain={[550, 800]}
              tickLine={false}
              axisLine={{ stroke: '#e2e8f0' }}
              tick={{ fontSize: 12, fill: '#64748b' }}
            />
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="bg-slate-900 text-white px-3 py-2 rounded-xl shadow-xl text-xs space-y-1">
                      <p className="font-bold text-emerald-400">{data.month || 'Record'}</p>
                      <p className="font-extrabold text-sm">CIBIL: {data.creditScore}</p>
                      {data.remarks && (
                        <p className="text-[10px] text-slate-300 font-normal italic">
                          {data.remarks}
                        </p>
                      )}
                    </div>
                  );
                }
                return null;
              }}
            />
            {/* Healthy Benchmark Reference Line at 750 (Very Good tier) */}
            <ReferenceLine
              y={740}
              stroke="#0d9488"
              strokeDasharray="4 4"
              label={{
                value: '740+ Prime Tier',
                position: 'insideTopRight',
                fill: '#0d9488',
                fontSize: 10,
                fontWeight: 600
              }}
            />
            <Area
              type="monotone"
              dataKey="creditScore"
              stroke="#059669"
              strokeWidth={3}
              fillOpacity={1}
              fill="url(#scoreAreaGradient)"
              activeDot={{ r: 6, fill: '#059669', stroke: '#fff', strokeWidth: 2 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Visual Explanation of the Trend */}
      <div className="mt-4 p-4 rounded-xl bg-emerald-50/70 border border-emerald-100 flex items-start gap-3">
        <Award className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
        <div>
          <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-wider">
            Trajectory Insights
          </h4>
          <p className="text-xs text-emerald-800 mt-0.5 leading-relaxed">
            {stats?.trendDescription ||
              `Your score has shown a steady upward climb of +${scoreChange} points (${percentageImprovement}%). Maintaining credit utilization below 30% and uninterrupted monthly EMI payments will position you to enter the 740+ Prime borrowing tier within 6-9 months.`}
          </p>
        </div>
      </div>
    </div>
  );
}
