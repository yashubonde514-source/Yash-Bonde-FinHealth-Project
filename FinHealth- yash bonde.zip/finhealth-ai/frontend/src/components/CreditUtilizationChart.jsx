import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { formatINR } from '../utils/formatters';
import { CreditCard, AlertCircle, CheckCircle2 } from 'lucide-react';

export default function CreditUtilizationChart({
  usedCredit = 35000,
  totalLimit = 100000,
  utilization = 35
}) {
  const safeUsed = Math.max(0, Number(usedCredit) || 0);
  const safeLimit = Math.max(safeUsed, Number(totalLimit) || 100000);
  const safeAvailable = Math.max(0, safeLimit - safeUsed);
  const calculatedUtilization = safeLimit > 0 ? Number(((safeUsed / safeLimit) * 100).toFixed(1)) : 0;

  const data = [
    { name: 'Used Credit', value: safeUsed, color: calculatedUtilization > 30 ? '#f59e0b' : '#059669' },
    { name: 'Available Credit', value: safeAvailable, color: '#e2e8f0' }
  ];

  const isOptimal = calculatedUtilization <= 30;

  return (
    <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-col justify-between">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div>
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <CreditCard className="w-4 h-4 text-emerald-600" />
            Credit Utilization
          </h3>
          <p className="text-xs text-slate-500">Card balance vs total sanctioned limit</p>
        </div>
        <span
          className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold rounded-full ${
            isOptimal
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : 'bg-amber-50 text-amber-700 border border-amber-200'
          }`}
        >
          {isOptimal ? (
            <>
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              Optimal (&lt;30%)
            </>
          ) : (
            <>
              <AlertCircle className="w-3 h-3 text-amber-600" />
              Exceeds 30% Guideline
            </>
          )}
        </span>
      </div>

      {/* Donut Chart with Center Metric */}
      <div className="relative h-48 my-2">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Tooltip
              formatter={(val, name) => [formatINR(val), name]}
              contentStyle={{
                backgroundColor: '#0f172a',
                color: '#fff',
                borderRadius: '8px',
                border: 'none',
                fontSize: '12px'
              }}
            />
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={55}
              outerRadius={75}
              paddingAngle={4}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>

        {/* Center Percentage Display */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-2xl font-extrabold text-slate-900">
            {calculatedUtilization}%
          </span>
          <span className="text-[11px] font-medium text-slate-400">
            Utilization
          </span>
        </div>
      </div>

      {/* Stats Breakdown */}
      <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-100">
        <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
          <span className="text-[11px] font-semibold text-slate-500 block">Used Credit</span>
          <span className="text-sm font-bold text-slate-900">{formatINR(safeUsed)}</span>
        </div>
        <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
          <span className="text-[11px] font-semibold text-slate-500 block">Available Credit</span>
          <span className="text-sm font-bold text-slate-900">{formatINR(safeAvailable)}</span>
        </div>
      </div>

      <div className="mt-3 text-[11px] text-slate-500 text-center">
        Total Credit Limit: <span className="font-semibold text-slate-800">{formatINR(safeLimit)}</span>
      </div>
    </div>
  );
}
